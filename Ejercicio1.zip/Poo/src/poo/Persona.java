package poo;

public class Persona {
	
	
	String nombre,Dni;
	int edad;
	public Persona(String nombre, String dni, int edad) {
		super();
		this.nombre = nombre;
		Dni = dni;
		this.edad = edad;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDni() {
		return Dni;
	}
	public void setDni(String dni) {
		Dni = dni;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public void mostrar () {
		System.out.println("Su nombre es = "+nombre);
		System.out.println("Su edad es = "+edad);
		System.out.println("No puede tener DNI porque es menor de edad");
	}
	public void Mayoredad() {
		System.out.println("Usted es mayor de edad puede entrar a la fiesta");
		
	}
	
	public void Dni() {
		System.out.println("Su DNI es = "+Dni);
	}
	public void mostrar2 () {
		System.out.println("Su nombre es = "+nombre);
		System.out.println("Su edad es = "+edad);
		System.out.println("Su DNI es = "+Dni);
	}
}
