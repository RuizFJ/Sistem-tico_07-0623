package poo;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		
		try {
		
		Persona op = new Persona("Francisco", "3611009051789B", 0);
		
		Scanner tc = new Scanner(System.in);
		
		int edad;
		do {
		System.out.println("Ingrese su edad");
		edad=tc.nextInt();
		} while(edad<=0);
		
		op.setEdad(edad);
		if (edad>=18) {
		op.mostrar2();
		op.Mayoredad();
		
		
		} else if (edad<18 && edad>=16) {
			op.mostrar2();
			
		}
		 if ( edad<16) {
			op.mostrar();
			
		}
		
		} catch (java.util.InputMismatchException e) {
			System.out.println("Error dato invalido");
		}

	}

}
