package poo;
import java.util.Scanner;
public class Racional {
	
	
	int num1,den1,num2,den2;
	int max,i,divisor=2,maximocd,mcd;
	double total1,total2;
	Scanner tc = new Scanner(System.in);

	public Racional(int num1, int den1, int num2, int den2) {
		super();
		this.num1 = num1;
		this.den1 = den1;
		this.num2 = num2;
		this.den2 = den2;
	}
	
	
	
	
	
	public int getDen1() {
		return den1;
	}





	public void setDen1(int den1) {
		this.den1 = den1;
	}





	public int getDen2() {
		return den2;
	}





	 void setDen2(int den2) {
		this.den2 = den2;
	}

	private void mcm() {
		
		
		max= den1;
		
		if (den2>max) {
			max=den2;
			i=max;
			while (i%den1!=0 || i%den2!=0) {
				i++;
				
			}	
		}
		
		if (den2<max) {
			max=den1;
			i=max;
			while (i%den1!=0 || i%den2!=0) {
				i++;
				
			}
			
		
		}else {
			i=den1;
		}
			
	}
	
	
	public void leer() {
		System.out.println("Ingrese el numerador ");
		num1=tc.nextInt();
		do {
		System.out.println("Ingrese el denominador");
		den1=tc.nextInt();
		} while (den1==0);
		System.out.println("Ingrese el numerador ");
		num2=tc.nextInt();
		do {
		System.out.println("Ingrese el denominador");
		den2=tc.nextInt();
		} while (den2==0);
		
	}
	
	
	
	public void comparar () {
		
		if (num1>den1 && num2>den2) {
			total1=(num1*10)/(den1);
			total2=(num2*10)/(den2);
		}
		
		
		if (total1>total2) {
			System.out.println("La primera fraccion es mayor a la segunda fraccion");
		}  if (total1<total2) {
			System.out.println("La segunda fraccion es mayor a la primera");
			
		} 
		 if (total1==total2) {
			System.out.println("Las fracciones son iguales");
			
		}
		
		
		
		
	}
	
	
	
	public void multi() {
		int nume3,deno3;
		
		nume3= num1*num2;
		deno3=den1*den2;
		
		mcd = simplificar (nume3,deno3);
		
		
		nume3 = nume3 / mcd;
		deno3 = deno3 / mcd;
	
		System.out.println("La multiplicacion de las fracciones es "+nume3+"/"+deno3);
		
	}
	public void divi() {
		int nume3,deno3;
		
		nume3= num1*den2;
		deno3=den1*num2;
		mcd = simplificar (nume3,deno3);
		nume3 = nume3 / mcd;
		deno3 = deno3 / mcd;
		
		System.out.println("La division de las fracciones es "+nume3+"/"+deno3);
		
	}
	
	public void suma() {
		mcm();
		int suma,suma2,sumtot;
		
		suma=(i/den1)*num1;
		suma2= (i/den2)*num2;
		sumtot= suma+suma2;
		mcd = simplificar (sumtot,i);
		sumtot = sumtot / mcd;
		i = i / mcd;
		
		System.out.println("La suma es "+sumtot+"/"+i);
		
	}
	public void resta() {
		mcm();
		int suma,suma2,sumtot;
		
		suma=(i/den1)*num1;
		suma2= (i/den2)*num2;
		sumtot= suma-suma2;
		
		mcd = simplificar (sumtot,i);
		sumtot = sumtot / mcd;
		i = i / mcd;
		
		System.out.println("La resta es "+sumtot+"/"+i);
		
	}
	
private static int simplificar(int a, int b) {
	
if (b==0) {
	return a;
} else 
	return simplificar(b, a%b);

	
}





}
