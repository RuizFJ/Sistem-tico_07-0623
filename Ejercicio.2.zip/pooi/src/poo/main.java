package poo;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		
		
		try {
		
		Racional op = new Racional(0, 0, 0, 0);
		
		
		Scanner tc = new Scanner(System.in);
		
		op.leer();
		
		op.multi();
		op.divi();
		op.suma();
		op.resta();
		op.comparar();
	
		
		} catch (java.util.InputMismatchException e) {
			System.out.println("Error dato invalido");
		}
		
	}

}
